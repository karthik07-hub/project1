package com.gamedetails.model;
import java.math.BigDecimal;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
@Entity
@Table(name = "Game_details")
public class GameDetails 
{

@Column(name = "gameid")
private Long gameid;
@Id
@Column(name = "player_id")
private String playerid;
@Column(name = "datee")
private String datee;

public GameDetails() {
	super();
	// TODO Auto-generated constructor stub
}

public GameDetails(Long game_id, String player_id, String datee, BigDecimal amount) {
	super();
	this.gameid = game_id;
	this.playerid = player_id;
	this.datee = datee;
	this.amount = amount;
}

public Long getGameid() {
	return gameid;
}

public void setGameid(Long game_id) {
	this.gameid = game_id;
}

public String getPlayer_id() {
	return playerid;
}

public void setPlayer_id(String player_id) {
	this.playerid = player_id;
}

public String getDatee() {
	return datee;
}

public void setDatee(String datee) {
	this.datee = datee;
}

public BigDecimal getAmount() {
	return amount;
}

public void setAmount(BigDecimal amount) {
	this.amount = amount;
}

@Column(name = "amount")
private BigDecimal amount;

}
