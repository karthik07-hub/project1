package com.gamedetails.model;

public class GameDetailsResponse {
	private String gameId;
	private long playerscount;
	private long gameAgeInDays;
	private String totalRevenueCollected;

	public String getGameId() {
		return gameId;
	}

	public void setGameId(String gameId) {
		this.gameId = gameId;
	}

	public long getPlayerscount() {
		return playerscount;
	}

	public void setPlayerscount(long playerids) {
		this.playerscount = playerids;
	}

	public long getGameAgeInDays() {
		return gameAgeInDays;
	}

	public void setGameAgeInDays(long gameAgeInDays) {
		this.gameAgeInDays = gameAgeInDays;
	}

	public String getTotalRevenueCollected() {
		return totalRevenueCollected;
	}

	public void setTotalRevenueCollected(String totalRevenueCollected) {
		this.totalRevenueCollected = totalRevenueCollected;
	}

}
