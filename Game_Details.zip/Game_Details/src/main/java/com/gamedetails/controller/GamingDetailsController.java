package com.gamedetails.controller;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;
import java.util.concurrent.TimeUnit;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

import com.gamedetails.model.GameDetailsResponse;
import com.gamedetails.repository.GamedetailsRepository;
@SpringBootApplication
@RestController 
public class GamingDetailsController 
{
@Autowired
private GamedetailsRepository gamedetailsRepository;

@GetMapping("/gamedetails/gameId/{gameId}")
public ResponseEntity<GameDetailsResponse> retrieveGameDetails(@PathVariable String gameId) throws ParseException
{
	long playerCount=gamedetailsRepository.getPlayerCount(gameId);
	String totalrevenue = gamedetailsRepository.getAmountCount(gameId);
	String mindate = gamedetailsRepository.getMinDate(gameId);
	String maxdate = gamedetailsRepository.getMaxDate(gameId);
	long diffDays = 0;
	
	SimpleDateFormat sdf = new SimpleDateFormat("MM/dd/yyyy", Locale.ENGLISH);
	if (mindate != null && maxdate != null) {
		Date firstDate = sdf.parse(mindate);
		Date secondDate = sdf.parse(maxdate);
	    long diffInMillies = Math.abs(secondDate.getTime() - firstDate.getTime());
		diffDays = TimeUnit.DAYS.convert(diffInMillies, TimeUnit.MILLISECONDS);
	}
	GameDetailsResponse response = new GameDetailsResponse();
	response.setGameId(gameId);
	response.setPlayerscount(playerCount);
	if (totalrevenue != null) {
		response.setTotalRevenueCollected(totalrevenue);
	} else {
		response.setTotalRevenueCollected("0");
	}
	response.setGameAgeInDays(diffDays);

	if (response != null) {
		return ResponseEntity.status(HttpStatus.OK.value()).body(response);
	}
	return ResponseEntity.status(HttpStatus.NO_CONTENT.value()).body(null);
}

}
