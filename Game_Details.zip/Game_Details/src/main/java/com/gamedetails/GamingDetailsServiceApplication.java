package com.gamedetails;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
@SpringBootApplication
public class GamingDetailsServiceApplication 
{
public static void main(String[] args) 
{
SpringApplication.run(GamingDetailsServiceApplication.class, args);
}
}
