package com.gamedetails.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.gamedetails.model.GameDetails;
import com.gamedetails.model.GameDetailsResponse;

@Repository
public interface GamedetailsRepository extends JpaRepository<GameDetails, Long> {


	List<GameDetailsResponse> findByGameid(String gameId);

	@Query(value = "Select count(*) from Game_details where gameid= :gameId", nativeQuery = true)
	public int  getPlayerCount(@Param("gameId")String gameId);

	@Query(value = "Select sum(amount) from Game_details where gameid= :gameId", nativeQuery = true)
	public String getAmountCount(@Param("gameId") String gameId);

	@Query(value = "Select min(datee) from Game_details where gameid= :gameId", nativeQuery = true)
	public String getMinDate(@Param("gameId") String gameId);

	@Query(value = "Select max(datee) from Game_details where gameid= :gameId", nativeQuery = true)
	public String getMaxDate(@Param("gameId") String gameId);

}
