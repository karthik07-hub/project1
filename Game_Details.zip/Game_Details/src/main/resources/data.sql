insert into Game_details(gameid,player_id,datee,amount)
values(101,'1', '06/24/2017',165);
insert into Game_details(gameid,player_id,datee,amount)
values(101,'2', '06/24/2018',265);
insert into Game_details(gameid,player_id,datee,amount)
values(101,'3', '06/24/2021',365);