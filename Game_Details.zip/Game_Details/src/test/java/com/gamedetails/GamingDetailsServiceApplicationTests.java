package com.gamedetails;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GamingDetailsServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
